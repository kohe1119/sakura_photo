export default function App() {
  return (
    <div className="p-4 text-xl">
      櫻坂46 生写真管理ツール、動いてます！
    </div>
  );
}
